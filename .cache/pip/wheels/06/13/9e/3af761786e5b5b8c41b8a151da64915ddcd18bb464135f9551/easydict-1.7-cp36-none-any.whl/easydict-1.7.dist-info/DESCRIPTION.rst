*EasyDict* allows to access dict values as attributes (works recursively). 
A Javascript-like properties dot notation for python dicts.

=====
USAGE
=====

::

    >>> from easydict import EasyDict as edict
    >>> d = edict({'foo':3, 'bar':{'x':1, 'y':2}})
    >>> d.foo
    3
    >>> d.bar.x
    1

    >>> d = edict(foo=3)
    >>> d.foo
    3


Very useful when exploiting parsed JSON content ! 

::

    >>> from easydict import EasyDict as edict
    >>> from simplejson import loads
    >>> j = """{
    "Buffer": 12,
    "List1": [
        {"type" : "point", "coordinates" : [100.1,54.9] },
        {"type" : "point", "coordinates" : [109.4,65.1] },
        {"type" : "point", "coordinates" : [115.2,80.2] },
        {"type" : "point", "coordinates" : [150.9,97.8] }
    ]
    }"""
    >>> d = edict(loads(j))
    >>> d.Buffer
    12
    >>> d.List1[0].coordinates[1]
    54.9

Can set attributes as easily as getting them :

::

    >>> d = EasyDict()
    >>> d.foo = 3
    >>> d.foo
    3

It is still a ``dict`` !

::

    >>> d = EasyDict(log=False)
    >>> d.debug = True
    >>> d.items()
    [('debug', True), ('log', False)]

Instance and class attributes are accessed like usual objects...

::

    >>> class Flower(EasyDict):
    ...     power = 1
    ...
    >>> f = Flower({'height': 12})
    >>> f.power
    1
    >>> f['power']
    1

=======
LICENSE
=======

* Lesser GNU Public License

=======
AUTHORS
=======

* Mathieu Leplatre <mathieu.leplatre@makina-corpus.com>

|makinacom|_

.. |makinacom| image:: http://depot.makina-corpus.org/public/logo.gif
.. _makinacom:  http://www.makina-corpus.com

Similar tools
=============

* `TreeDict <http://pypi.python.org/pypi/treedict>`_, a fast and full-featured dict-like tree container.
* `addict <https://github.com/mewwts/addict>`_


=========
CHANGELOG
=========

1.7 (2017-04-27)
================

* Prevent copying sub-EasyDicts on assignment to fix unpickling (#7, thanks @Chronos-Sk)

1.6 (2015-01-27)
================

* Allow setting attributes via setting items (thanks phivos)

1.5 (2014-08-07)
================

* Allow subclassing using self instead of class name (thanks Steve Engledow)

1.4 (2011-03-13)
================

* Access class attributes like instance attributes

1.3 (2012-02-08)
================

* Better documentation and tests

1.2 (2011-06-08)
================

* Fix inclusion of README

1.1 (2012-04-21)
================

* Switch to distutils2

1.0 (2011-04-18)
================

* Initial working version


