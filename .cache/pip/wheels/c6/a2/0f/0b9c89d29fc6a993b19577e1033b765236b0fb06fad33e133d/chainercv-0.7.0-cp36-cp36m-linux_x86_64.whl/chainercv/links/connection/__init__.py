from chainercv.links.connection.conv_2d_activ import Conv2DActiv  # NOQA
from chainercv.links.connection.conv_2d_bn_activ import Conv2DBNActiv  # NOQA
