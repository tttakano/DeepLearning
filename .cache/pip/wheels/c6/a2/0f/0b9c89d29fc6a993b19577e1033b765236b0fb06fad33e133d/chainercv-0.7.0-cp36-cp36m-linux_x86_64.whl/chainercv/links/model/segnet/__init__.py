from chainercv.links.model.segnet.segnet_basic import SegNetBasic  # NOQA
