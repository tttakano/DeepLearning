import pkg_resources

from chainercv import datasets  # NOQA
from chainercv import evaluations  # NOQA
from chainercv import extensions  # NOQA
from chainercv import functions  # NOQA
from chainercv import links  # NOQA
from chainercv import transforms  # NOQA
from chainercv import utils  # NOQA
from chainercv import visualizations  # NOQA


__version__ = pkg_resources.get_distribution('chainercv').version
