from chainercv.links.model.vgg.vgg16 import VGG16  # NOQA
