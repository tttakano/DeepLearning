from chainer.dataset import convert  # NOQA
from chainer.dataset import dataset_mixin  # NOQA
from chainer.dataset import download  # NOQA
from chainer.dataset import iterator  # NOQA


# import class and function
from chainer.dataset.convert import concat_examples  # NOQA
from chainer.dataset.convert import to_device  # NOQA
from chainer.dataset.dataset_mixin import DatasetMixin  # NOQA
from chainer.dataset.download import cache_or_load_file  # NOQA
from chainer.dataset.download import cached_download  # NOQA
from chainer.dataset.download import get_dataset_directory  # NOQA
from chainer.dataset.download import get_dataset_root  # NOQA
from chainer.dataset.download import set_dataset_root  # NOQA
from chainer.dataset.iterator import Iterator  # NOQA
