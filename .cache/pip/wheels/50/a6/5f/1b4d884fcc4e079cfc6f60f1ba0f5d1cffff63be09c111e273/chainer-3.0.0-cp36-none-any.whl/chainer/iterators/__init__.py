from chainer.iterators import multiprocess_iterator  # NOQA
from chainer.iterators import serial_iterator  # NOQA


# import class and function
from chainer.iterators.multiprocess_iterator import MultiprocessIterator  # NOQA
from chainer.iterators.serial_iterator import SerialIterator  # NOQA
